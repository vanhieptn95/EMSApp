'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'album';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f89f';
var svgPathData = 'M224 416c88.22 0 160-71.78 160-160S312.22 96 224 96 64 167.78 64 256s71.78 160 160 160zm0-288A128 128 0 1 1 96 256a128.14 128.14 0 0 1 128-128zm0 152a24 24 0 1 0-24-24 24 24 0 0 0 24 24zM416 32H32A32 32 0 0 0 0 64v384a32 32 0 0 0 32 32h384a32 32 0 0 0 32-32V64a32 32 0 0 0-32-32zm0 416H32V64h384z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faAlbum = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;