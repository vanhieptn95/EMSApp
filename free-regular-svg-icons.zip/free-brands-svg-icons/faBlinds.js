'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blinds';
var width = 512;
var height = 512;
var ligatures = [];
var unicode = 'f8fb';
var svgPathData = 'M500.48,352h-33l8,32H36.5l8-32h-33l-11,44.12A16,16,0,0,0,16,416H496a16,16,0,0,0,15.52-19.88Zm0,96h-33l8,32H36.5l8-32h-33l-11,44.12A16,16,0,0,0,16,512H496a16,16,0,0,0,15.52-19.88ZM496,0H16A16,16,0,0,0,0,16V80A16,16,0,0,0,16,96H128v96H36.5l16-64h-33l-19,76.12A16,16,0,0,0,16,224H128v34.94A47.82,47.82,0,0,0,98.94,288H36.5l8-32h-33l-11,44.12A16,16,0,0,0,16,320H98.94A47.89,47.89,0,1,0,160,258.94V96H496a16,16,0,0,0,16-16V16A16,16,0,0,0,496,0ZM144,320a16,16,0,1,1,16-16A16,16,0,0,1,144,320ZM480,64H32V32H480Zm12.48,64h-33l16,64H192v32H496a16,16,0,0,0,15.52-19.88Zm8,128h-33l8,32H222.39a80.31,80.31,0,0,1,0,32H496a16,16,0,0,0,15.52-19.88Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faBlinds = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;