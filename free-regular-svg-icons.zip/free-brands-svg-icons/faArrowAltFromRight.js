'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-alt-from-right';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f348';
var svgPathData = 'M448 76v360c0 6.6-5.4 12-12 12h-8c-6.6 0-12-5.4-12-12V76c0-6.6 5.4-12 12-12h8c6.6 0 12 5.4 12 12zm-96 218.9v-77.7c0-8.8-7.2-16-16-16H192v-93.9c0-7.1-8.6-10.7-13.6-5.7L36.7 244.7c-6.3 6.3-6.3 16.4 0 22.7l141.6 143.1c5 5 13.6 1.5 13.6-5.7v-93.9h144c8.9 0 16.1-7.2 16.1-16m32 0c0 26.5-21.5 48-48 48H224v61.9c0 35.6-43.1 53.4-68.2 28.3L14.1 290c-18.8-18.8-18.8-49.2 0-68L155.8 78.9C181 53.8 224 71.8 224 107.3v61.9h112c26.5 0 48 21.5 48 48v77.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faArrowAltFromRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;