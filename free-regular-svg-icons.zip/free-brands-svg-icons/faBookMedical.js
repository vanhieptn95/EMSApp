'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-medical';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f7e6';
var svgPathData = 'M448 392V24a23.94 23.94 0 0 0-24-24H80A80 80 0 0 0 0 80v368a64 64 0 0 0 64 64h372a12 12 0 0 0 12-12v-8a12 12 0 0 0-12-12h-3.3c-4-20.2-3.2-49.7.4-65.8A24.1 24.1 0 0 0 448 392zm-43.7 88H64a32 32 0 0 1 0-64h340.3a228.6 228.6 0 0 0 0 64zm11.7-96H64a63.33 63.33 0 0 0-32 8.88V80a48 48 0 0 1 48-48h336zM152 240h56v56a8 8 0 0 0 8 8h48a8 8 0 0 0 8-8v-56h56a8 8 0 0 0 8-8v-48a8 8 0 0 0-8-8h-56v-56a8 8 0 0 0-8-8h-48a8 8 0 0 0-8 8v56h-56a8 8 0 0 0-8 8v48a8 8 0 0 0 8 8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faBookMedical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;