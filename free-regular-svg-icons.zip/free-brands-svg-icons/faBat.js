'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bat';
var width = 640;
var height = 512;
var ligatures = [];
var unicode = 'f6b5';
var svgPathData = 'M638.61 287.25L568.3 129.7c-5.48-12.27-17.85-19.4-30.67-19.4-5.81 0-11.7 1.46-17.1 4.57l-104.9 60.44L384 64l-50.11 48h-27.77L256 64l-31.62 111.3-104.9-60.44c-5.4-3.11-11.3-4.57-17.1-4.57-12.83 0-25.2 7.13-30.67 19.4L1.39 287.25c-5.66 12.69 6.94 25.85 20.58 21.48l16.48-5.27a69.132 69.132 0 0 1 21.07-3.29c21.83 0 42.85 10.33 55.46 28.51L153.39 384l12.31-11.82c13.11-12.59 30.14-18.75 47.09-18.75 20.13 0 40.15 8.69 53.36 25.6L320 448l53.86-68.97c13.21-16.91 33.23-25.6 53.36-25.6 16.95 0 33.98 6.16 47.09 18.75l12.3 11.82 38.41-55.33c12.61-18.17 33.63-28.51 55.46-28.51 7.02 0 14.13 1.07 21.07 3.29l16.48 5.27c13.64 4.38 26.24-8.78 20.58-21.47zm-58.13-19.08c-33.5 0-64.6 15.98-83.19 42.76l-17.32 24.95c-15.69-9.41-33.82-14.44-52.76-14.44-31.79 0-60.96 14-80.01 38.4L320 394.67l-27.2-34.83c-19.06-24.4-48.22-38.4-80.02-38.4-18.94 0-37.07 5.03-52.76 14.44l-17.32-24.95c-18.59-26.77-49.68-42.76-83.19-42.76-4.62 0-9.21.31-13.77.92l56.58-126.78 143.47 82.66 26.05-100.06 20.99 19.1h54.33l20.99-19.1 26.05 100.06 143.47-82.66 56.58 126.78c-4.55-.62-9.15-.92-13.77-.92z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;