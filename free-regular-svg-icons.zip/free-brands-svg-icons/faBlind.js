'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blind';
var width = 384;
var height = 512;
var ligatures = [];
var unicode = 'f29d';
var svgPathData = 'M206.817 489.959c3.334 8.184-.598 17.521-8.78 20.854-8.166 3.329-17.515-.582-20.854-8.78L110.14 337.476l15.549-46.648 81.128 199.131zM102.663 121.531a4 4 0 0 1 6.562-4.577l112.933 161.912c3.815 5.468 11.307 6.742 16.708 2.976 5.356-3.737 6.796-11.232 2.976-16.708l-120-172a11.978 11.978 0 0 0-9.842-5.13V88H80v.013c-3.294.001-6.574 1.337-8.943 3.985L0 171.415V272c0 6.627 5.373 12 12 12s12-5.373 12-12v-91.415l48-53.646v198.465L16.821 490.936c-2.795 8.383 1.736 17.444 10.119 20.238 8.381 2.794 17.444-1.735 20.238-10.119L120 282.597v-136.21l-17.337-24.856zm280.725 384.343L245.791 286.463a20.279 20.279 0 0 1-6.78 4.245l137.6 219.416a4 4 0 1 0 6.777-4.25zM96 0C73.909 0 56 17.909 56 40s17.909 40 40 40 40-17.909 40-40S118.091 0 96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faBlind = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;