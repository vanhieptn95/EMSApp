'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'baseball-ball';
var width = 496;
var height = 512;
var ligatures = [];
var unicode = 'f433';
var svgPathData = 'M248 8C111.2 8 0 119.2 0 256s111.2 248 248 248 248-111.2 248-248S384.8 8 248 8zM103.5 416.1c16.7-17.4 30.6-37.2 41.3-59.1L118 344c-9.1 18.8-21.8 35.1-36 50-85.6-102.8-45.3-221.5 0-276 14.2 14.9 26.8 31.2 36 49.8l26.8-13.1c-10.6-21.8-24.5-41.5-41.2-58.9 79.1-71.4 203.1-77.6 289-.1-16.7 17.4-30.6 37.1-41.2 59l26.8 13c9.1-18.7 21.7-35 36-50 78.1 93.7 54.6 210.4.1 275.9-14.3-14.9-26.9-31.2-36-49.9l-26.8 13.1c10.7 21.9 24.5 41.6 41.3 58.9-90 81.5-214.3 68.2-289.3.4zm53.2-88.6l-28.3-9.2c12.2-37.5 14-81.5-.1-124.7l28.3-9.2c16.3 50 14 100.4.1 143.1zm211-9.2l-28.3 9.2c-16.3-50-14-100.5-.1-143.1l28.3 9.2c-12.2 37.6-13.9 81.6.1 124.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faBaseballBall = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;