'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'atlas';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f558';
var svgPathData = 'M448 392V24c0-13.3-10.7-24-24-24H80C35.8 0 0 35.8 0 80v368c0 35.35 28.65 64 64 64h372c6.6 0 12-5.4 12-12v-8c0-6.6-5.4-12-12-12h-3.3c-4-20.2-3.2-49.7.4-65.8 8.7-3.6 14.9-12.2 14.9-22.2zm-43.7 88H64c-17.67 0-32-14.33-32-32s14.33-32 32-32h340.3c-2.9 18.8-3.1 43.6 0 64zm11.7-96H64c-11.72 0-22.55 3.38-32 8.88V80c0-26.5 21.5-48 48-48h336v352zm-192-48c70.69 0 128-57.31 128-128S294.69 80 224 80 96 137.31 96 208s57.31 128 128 128zm94.38-144h-39.09c-1.49-27.03-6.54-51.35-14.21-70.41 27.71 13.24 48.02 39.19 53.3 70.41zm-39.09 32h39.09c-5.29 31.22-25.59 57.17-53.3 70.41 7.68-19.06 12.72-43.38 14.21-70.41zM224 113.31c7.69 7.45 20.77 34.42 23.43 78.69h-46.87c2.67-44.26 15.75-71.24 23.44-78.69zM247.43 224c-2.66 44.26-15.74 71.24-23.43 78.69-7.69-7.45-20.77-34.42-23.43-78.69h46.86zm-64.51-102.41c-7.68 19.06-12.72 43.38-14.21 70.41h-39.09c5.28-31.22 25.59-57.17 53.3-70.41zM168.71 224c1.49 27.03 6.54 51.35 14.21 70.41-27.71-13.24-48.02-39.19-53.3-70.41h39.09z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faAtlas = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;